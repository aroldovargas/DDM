package com.example.minhalista;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

public class NewItemActivity extends AppCompatActivity {
    static int PHOTO_PICKER_REQUEST = 1;
    Uri selectPhotoLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_item);
        ImageButton imgBtnGalery = findViewById(R.id.imgBtnGalery);
        imgBtnGalery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent photoPickerIntent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                //determina o diretorio onde estao as imagens e formato
                photoPickerIntent.setType("Image/*");
               // inicia a janela para escolher a imagem com todas as imagens
                startActivityForResult(photoPickerIntent, PHOTO_PICKER_REQUEST);
            }
        });
    }
    //Recebe parametros identificando qual a ação que esta sendo realizada ou seja qual foi a requisicao, o resultado da requisição e o arquivo.
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //Verifica a requisicao
        if(requestCode == PHOTO_PICKER_REQUEST);
        {
            //Verifica se a pessoa escolheu a foto
            if (resultCode == Activity.RESULT_OK){
                //Aponta para o endereço/foto selecionada
                selectPhotoLocation = data.getData();
                //Insere a imagem/endereco no elemento de interface destinado a exibir a imagem
                ImageView imgViewPhoto = findViewById(R.id.imgViewPhoto);
                imgViewPhoto.setImageURI(selectPhotoLocation);
            }
        }
    }
}